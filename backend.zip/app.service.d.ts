/// <reference types="multer" />
export declare class AppService {
    private s3Client;
    private dynamoClient;
    constructor();
    uploadImage(image: Express.Multer.File): Promise<{
        id: `${string}-${string}-${string}-${string}-${string}`;
        url: string;
    }>;
    getImages(): Promise<{}[]>;
    private parseDynamoItem;
}

/// <reference types="multer" />
import { AppService } from './app.service';
export declare class AppController {
    private readonly appService;
    constructor(appService: AppService);
    getImages(): Promise<{}[]>;
    uploadImage(image: Express.Multer.File): Promise<{
        id: `${string}-${string}-${string}-${string}-${string}`;
        url: string;
    }>;
}
